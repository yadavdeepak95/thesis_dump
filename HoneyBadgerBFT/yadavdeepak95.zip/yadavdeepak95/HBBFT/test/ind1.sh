#!/bin/sh

go run main.go 1 2>&1 | tee  1.log
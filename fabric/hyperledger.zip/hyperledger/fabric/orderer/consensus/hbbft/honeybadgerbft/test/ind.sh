#!/bin/sh

go run main.go 0 2>&1 | tee  0.log
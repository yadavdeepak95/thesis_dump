#!/bin/sh

go run main.go 3 2>&1 | tee  3.log
#!/bin/sh

gnome-terminal -e "./ind.sh"
gnome-terminal -e "./ind1.sh"
gnome-terminal -e "./ind2.sh"
gnome-terminal -e "./ind3.sh"
#!/bin/sh

go run main.go 2 2>&1 | tee  2.log
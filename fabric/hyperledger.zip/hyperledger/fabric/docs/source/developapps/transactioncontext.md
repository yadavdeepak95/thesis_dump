# Transaction context

Content being added in FAB-10440

## Structure

<!--- Licensed under Creative Commons Attribution 4.0 International License
https://creativecommons.org/licenses/by/4.0/ -->

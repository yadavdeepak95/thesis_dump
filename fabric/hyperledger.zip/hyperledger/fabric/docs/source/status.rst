Status
=================

Hyperledger Fabric is in the *Active* state. For more information on the history of this project see our `wiki page <https://wiki.hyperledger.org/projects/fabric#history>`__. Information on what *Active* entails can be found in
the Hyperledger `Project Lifecycle document <https://wiki.hyperledger.org/community/project-lifecycle>`__.

.. Licensed under Creative Commons Attribution 4.0 International License
   https://creativecommons.org/licenses/by/4.0/

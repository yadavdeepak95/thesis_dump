Key Concepts
============

.. toctree::
   :maxdepth: 1

   blockchain
   functionalities
   fabric_model
   network/network.md
   identity/identity.md
   membership/membership.md
   peers/peers.md
   smartcontract/smartcontract.md
   ledger/ledger.md
   orderer/ordering_service.md
   private-data/private-data.md
   capabilities_concept.md
   usecases

# cryptogen

`cryptogen` is an utility for generating Hyperledger Fabric key material.
It is provided as a means of preconfiguring a network for testing purposes.
It would normally not be used in the operation of a production network.

## Syntax

The ``cryptogen`` command has five subcommands, as follows:

  * help
  * generate
  * showtemplate
  * extend
  * version

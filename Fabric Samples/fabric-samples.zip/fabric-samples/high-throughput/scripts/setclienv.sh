#
# Copyright IBM Corp All Rights Reserved
#
# SPDX-License-Identifier: Apache-2.0
#

export CHANNEL_NAME=mychannel
export CC_NAME=bigdatacc

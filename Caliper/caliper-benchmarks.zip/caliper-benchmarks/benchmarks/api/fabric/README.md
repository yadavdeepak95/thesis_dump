# Fabric API Tests

This folder contains tests that target Fabric shim API methods that may be called within chaincode
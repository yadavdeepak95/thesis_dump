# API Tests

This folder contains tests that are directed to the APIs of the blockchain technologies.
# Scenario tests

This folder contains tests that are generic across all blockchain technologies. Their specific implementations are different, and bespoke to the technology under test, but the outcome is the same.
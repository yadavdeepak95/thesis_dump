# FixedAsset Hyperledger Fabric Java contract for Performance Testing

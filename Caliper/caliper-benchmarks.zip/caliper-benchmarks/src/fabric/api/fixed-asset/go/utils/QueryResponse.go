package utils

// QueryResponse - manage results from query
type QueryResponse struct {
	Results          interface{}
	ResponseMetadata ResponseMetadata
}

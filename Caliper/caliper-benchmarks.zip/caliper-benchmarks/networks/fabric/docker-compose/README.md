This folder contains sample Fabric networks for testing with caliper. Each network requires an environment variable to be set for:
 - `FABRIC_VERSION` the core Fabric version
 - `FABRIC_CA_VERSION` the Fabric CA version

Please inspect nested folder README files for more information.
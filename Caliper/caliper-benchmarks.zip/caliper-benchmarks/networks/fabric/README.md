# Fabric Networks

The enclosed Fabric networks are provided *without* crypto configuration. The network of interest needs to be bootstrapped by running the `generate.sh` script that is present within each `/fabric/config_<type>` folder. This *must* be done prior to running any benchmarks as the crypto-configuration files are required.